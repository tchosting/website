jQuery(document).ready(function ($) {
    $('input.popup-colorpicker').wpColorPicker();
});
